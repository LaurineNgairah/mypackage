# mypackage
This library showcases a function that orders an array of numbers in descending order